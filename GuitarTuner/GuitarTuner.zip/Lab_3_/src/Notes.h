#if !defined(NOTES_H)
#define NOTES_H

int freq_to_note(float frequency, int current_note);
int diff_to_note(int note_target, int note_current);

#endif // NOTES_H
