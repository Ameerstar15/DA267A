#include <math.h>
#include <stdio.h>
#include <esp_log.h>

#include "Notes.h"

char *notes[] = {"A", "A#", "B", "C", "C#", "D",
                 "D#", "E", "F", "F#", "G#", "G"};

int freq_to_note(float frequency, int current_note)
{

    // Convert frequency to note and change current_note to that note

    float f = round(12 * log2(frequency / 440));
    int semitones = round(f);

    /* if (semitones < 0)
     {
         semitones += 12;
     }*/
    // printf("semitones : %d \n", semitones);
    return semitones;
}

int diff_to_note(int note_target_nr, int note_current)
{

    printf("current :%d\n", note_current);
    printf("note target : %c\n", *notes[note_target_nr]);

    // posetiva värden är nu klara
    if (note_current >= 0 && note_target_nr >= 0)
    {
        if (note_current <= note_target_nr)
        {

            return note_current - note_target_nr;
        }
        if (note_current > note_target_nr)
        {
            return note_current - note_target_nr;
        }
    }
    //negativa värden är klara
    if (note_current < 0 && note_target_nr < 0)
    {
        if (note_current <= note_target_nr)
        {

            return note_current - note_target_nr;
        }
    }
    else
    {
        return note_current;
    }
    /*if (note_current < 0 )
    {


        printf("note current < 0 \n");
        return note_current;
    }

    if (note_current > 0)
    {
        return note_current - note_target_nr;
    }
    if (note_current == 0 )
    {
        return -note_target_nr;
    }*/
}